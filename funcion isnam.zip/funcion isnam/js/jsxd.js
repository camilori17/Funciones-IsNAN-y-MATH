console.log(Number.NaN);
console.log(NaN);
console.log(typeof (Number));

let variable = "JavaScript";
let numero = parseInt(variable);
console.log(numero);

console.log(isNaN(NaN));
let edad;
do{
    edad=parseInt(prompt("Ingrese su edad: "));
} while(isNaN(edad));
