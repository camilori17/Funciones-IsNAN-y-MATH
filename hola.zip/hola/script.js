let numero=parseInt(Math.random()*1000);
alert(numero);
