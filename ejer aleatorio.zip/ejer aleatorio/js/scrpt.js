   
    let numero = parseInt(Math.random()*100);
    alert(numero);
    
