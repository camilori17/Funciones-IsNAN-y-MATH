// Pedimos al usuario que ingrese los datos
let nombre1 = prompt("Ingresa el primer nombre:");
let edad1 = parseInt(prompt("Ingresa la edad de " + nombre1 + ":"));
let nombre2 = prompt("Ingresa el segundo nombre:");
let edad2 = parseInt(prompt("Ingresa la edad de " + nombre2 + ":"));
let nombre3 = prompt("Ingresa el tercer nombre:");
let edad3 = parseInt(prompt("Ingresa la edad de " + nombre3 + ":"));

// Validamos cuál es la mayor edad
let mayorEdad = 0;
let nombreMayorEdad = "";
if (edad1 > mayorEdad) {
  mayorEdad = edad1;
  nombreMayorEdad = nombre1;
}
if (edad2 > mayorEdad) {
  mayorEdad = edad2;
  nombreMayorEdad = nombre2;
}
if (edad3 > mayorEdad) {
  mayorEdad = edad3;
  nombreMayorEdad = nombre3;
}

// Mostramos el mensaje con el nombre de la persona de mayor edad
alert("La persona de mayor edad es " + nombreMayorEdad + ", con " + mayorEdad + " años.");
